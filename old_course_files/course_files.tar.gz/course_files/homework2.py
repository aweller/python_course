#############################################################################################
# TASK 2

regulation_file = "gene_upregulation.txt"

gene_id_to_pvalue = {}                          # create an empty dictionary 

with open(regulation_file) as regulation:       # open the file
    for row in regulation:                      # iterate over the rows
         
            fields = row.split()                # split the row into columns          
            gene_id = fields[0]                 # give variable names to the columns
            fold_change = float(fields[1])
            pvalue = float(fields[2])
            
            #if pvalue < 0.01:
            #    print row,
                
            gene_id_to_pvalue[gene_id] = pvalue # insert the field into the dictionary
            
            
#############################################################################################
# TASK 3

name_file = "gene_names.txt"

with open(name_file) as names:
    for row in names:
        fields = row.split()    

        homolog = fields[1]
        gene_id = fields[3]
        
        if homolog != gene_id:                  # check if this row has a C.elegans homolog
            
            pvalue = gene_id_to_pvalue[gene_id] # retrieve the pvalue from the dictionary
            
            if pvalue < 0.01:
                print row,