import sys                              # import the module for the argument parsing

row_number_cutoff = int(sys.argv[1])    # parse the argument and transform it into an integer
nexus_file = "101strains.nex"
row_counter = 0                         # create a counter with the starting value zero

with open(nexus_file) as nexus:         # open the file
    for row in nexus:                   # iterate over the rows
        if "GATTA" in row:              # check if its a sequence row
            row_counter += 1            # increase the counter value by one
            print row,
            
            if row_counter > row_number_cutoff: # check if the condition has been fulfilled
                break                   # stop the for loop